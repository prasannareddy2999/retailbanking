insert into appuser (userid,username,password,role) values ('SBEM000001','emp','emp','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('SBEM000002','employee','emp','EMPLOYEE');
insert into appuser (userid,username,password,role) values ('SBCU000000','cust','cust','CUSTOMER');