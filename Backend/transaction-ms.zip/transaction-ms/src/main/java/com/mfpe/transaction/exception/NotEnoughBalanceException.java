package com.mfpe.transaction.exception;

public class NotEnoughBalanceException extends RuntimeException {

	/**
	 * NotEnoughAmountException Exception Class
	 */
	private static final long serialVersionUID = -8484756789948882122L;

	public NotEnoughBalanceException() {
		super();
	}

}
