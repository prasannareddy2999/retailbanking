package com.mfpe.transaction.exception;

public class InvalidTransactionException extends RuntimeException {

	/**
	 * InvalidTransactionException Exception Class
	 */
	private static final long serialVersionUID = -5681516855330931499L;

	public InvalidTransactionException() {
		super();
	}

}