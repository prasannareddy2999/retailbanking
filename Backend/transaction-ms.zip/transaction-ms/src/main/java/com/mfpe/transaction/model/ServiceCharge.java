package com.mfpe.transaction.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ServiceCharge {
	
	private String accountId;
	private String message;
	private double balance;
	
}
