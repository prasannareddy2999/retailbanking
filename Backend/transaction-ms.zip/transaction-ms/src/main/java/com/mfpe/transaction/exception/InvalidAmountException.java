package com.mfpe.transaction.exception;

public class InvalidAmountException extends RuntimeException {

	/**
	 * ZeroAmountException Exception Class
	 */
	private static final long serialVersionUID = -39205050435390804L;

	public InvalidAmountException() {
		super();
	}

}
