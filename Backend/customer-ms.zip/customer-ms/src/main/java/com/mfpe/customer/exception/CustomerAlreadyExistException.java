package com.mfpe.customer.exception;

public class CustomerAlreadyExistException extends RuntimeException {

	/**
	 * CustomerAlreadyExistException Exception Class
	 */
	private static final long serialVersionUID = -9077866631588338462L;

	public CustomerAlreadyExistException() {
		super();
	}
	
}
