package com.mfpe.customer.model;

public enum Gender {
	
	MALE,
	FEMALE,
	OTHERS
}
