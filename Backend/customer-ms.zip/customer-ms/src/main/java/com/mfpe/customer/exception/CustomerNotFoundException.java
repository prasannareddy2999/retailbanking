package com.mfpe.customer.exception;

public class CustomerNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8445340862384469098L;

	public CustomerNotFoundException() {
		super();
	}

}
