package com.mfpe.customer.exception;

public class TokenNotFoundException extends RuntimeException {

	/**
	 * TokenNotFoundException Exception Class
	 */
	private static final long serialVersionUID = -6481965221919278587L;

	public TokenNotFoundException() {
		super();
	}
	
}
