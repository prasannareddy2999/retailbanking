package com.mfpe.account;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountMsApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
