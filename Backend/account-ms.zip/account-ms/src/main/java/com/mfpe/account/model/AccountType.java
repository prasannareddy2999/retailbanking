package com.mfpe.account.model;

public enum AccountType {

	/**
	 *  AccountType enum for account categories
	 */
	SAVINGS,
	CURRENT
	
}
