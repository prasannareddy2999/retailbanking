package com.mfpe.account.exception;

public class IncorrectDateInputException extends RuntimeException {

	/**
	 * DateInputException Exception Class
	 */
	private static final long serialVersionUID = -2260479592034067215L;

	public IncorrectDateInputException() {
		super();
	}

}
