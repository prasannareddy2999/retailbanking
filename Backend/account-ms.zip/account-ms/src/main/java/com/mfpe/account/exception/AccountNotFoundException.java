package com.mfpe.account.exception;

public class AccountNotFoundException extends RuntimeException{

	/**
	 * AccountNotFoundException Exception Class
	 */
	private static final long serialVersionUID = -6158258448697521823L;

	public AccountNotFoundException() {
		super();
	}

}
