package com.mfpe.account.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class TransactionsHistory {

	/**
	 * TransactionsHistory Model class
	 */
	@SuppressWarnings("unused")
	private long id;

	@SuppressWarnings("unused")
	private String transactionId;

	@SuppressWarnings("unused")
	private String transactionType;

	@SuppressWarnings("unused")
	private String sourceAccountId;

	@SuppressWarnings("unused")
	private String destinationAccountId;

	@SuppressWarnings("unused")
	private double amount;

	private static final String MY_TIME_ZONE = "Asia/Kolkata";

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm", timezone = MY_TIME_ZONE)
	@Getter
	private Date dateOfTransaction;

	@SuppressWarnings("unused")
	private String transactionStatus;

	@SuppressWarnings("unused")
	private double sourceBalance;

	@SuppressWarnings("unused")
	private double destinationBalance;

}
