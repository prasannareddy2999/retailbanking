package com.mfpe.account.exception;

public class AccessDeniedException extends RuntimeException {

	/**
	 * AccessDeniedException Exception Class
	 */
	private static final long serialVersionUID = 3614881436315163492L;

	public AccessDeniedException() {
		super();
	}

}