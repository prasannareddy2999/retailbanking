package com.mfpe.rule.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.mfpe.rule.dto.RuleStatus;
import com.mfpe.rule.dto.ServiceCharge;
import com.mfpe.rule.exception.TokenNotFoundException;
import com.mfpe.rule.feign.AccountFeign;
import com.mfpe.rule.model.Account;
import com.mfpe.rule.model.AccountDto;
import com.mfpe.rule.model.AccountType;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class RuleServiceImplTest {

	@Mock
	private AccountFeign accountClient;

	@InjectMocks
	private RuleServiceImpl ruleService;

	private Account account1, account2;
	private AccountDto accountDto1, accountDto2;
	private RuleStatus status;
	private ServiceCharge charges;
	
	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
	}

	@BeforeEach
	public void setup() {

		account1 = new Account("SBACS000001", "SBCU000001", 2000.0, AccountType.SAVINGS);
		account2 = new Account("SBACS000001", "SBCU000001", 500.0, AccountType.SAVINGS);
		accountDto1 = new AccountDto("SBACS000001", 2000.0);
		accountDto2 = new AccountDto("SBACS000001", 500.0);

	}

	@Test
	@Order(1)
	void testEvaluateMinBalWithClosingBalanceGreatherThan1000() {

		when(accountClient.getAccount("token", account1.getAccountId()))
				.thenReturn(new ResponseEntity<>(accountDto1, HttpStatus.OK));

		status = this.ruleService.evaluateMinBal(1000.0, account1.getAccountId(), "token");

		assertThat(status.getStatus()).isEqualTo("Allowed");
		assertThat(status.getMessage()).isEqualTo("Completely OK");

	}

	@Test
	@Order(2)
	void testEvaluateMinBalWithClosingBalanceLessThan1000GreatherThan0() {

		when(accountClient.getAccount("token", account1.getAccountId()))
				.thenReturn(new ResponseEntity<>(accountDto1, HttpStatus.OK));

		status = this.ruleService.evaluateMinBal(2000.0, account1.getAccountId(), "token");

		assertThat(status.getStatus()).isEqualTo("Allowed");
		assertThat(status.getMessage()).isEqualTo("Partially OK");

	}

	@Test
	@Order(3)
	void testEvaluateMinBalWithClosingBalanceLessThan0() {

		when(accountClient.getAccount("token", account1.getAccountId()))
				.thenReturn(new ResponseEntity<>(accountDto1, HttpStatus.OK));

		status = this.ruleService.evaluateMinBal(3000.0, account1.getAccountId(), "token");

		assertThat(status.getStatus()).isEqualTo("Denied");
		assertThat(status.getMessage()).isEqualTo("Not OK");

	}

	@Test
	@Order(4)
	void testInvalidEvaluateMinBal() {

		Assertions.assertThrows(TokenNotFoundException.class,
				() -> this.ruleService.evaluateMinBal(1000.0, account1.getAccountId(), null));

	}

	@Test
	@Order(5)
	void testGetServiceChargesGreatherThan1000() {

		when(accountClient.getAccount("token", account1.getAccountId()))
				.thenReturn(new ResponseEntity<>(accountDto1, HttpStatus.OK));

		charges = ruleService.getServiceCharges(account1.getAccountId(), "token");

		assertThat(charges.getAccountId()).isEqualTo(account1.getAccountId());
		assertThat(charges.getMessage()).isEqualTo("maintaining minimum amount, no detection");
		assertThat(charges.getBalance()).isEqualTo(account1.getBalance());

	}

	@Test
	@Order(6)
	void testGetServiceChargesLessThan1000() {

		when(accountClient.getAccount("token", account2.getAccountId()))
				.thenReturn(new ResponseEntity<>(accountDto2, HttpStatus.OK));

		charges = ruleService.getServiceCharges(account2.getAccountId(), "token");

		assertThat(charges.getAccountId()).isEqualTo(account2.getAccountId());
		assertThat(charges.getMessage()).isEqualTo("balance is less than 1000, 10% from your account is detected");
		assertThat(charges.getBalance()).isEqualTo(account2.getBalance() - account2.getBalance() / 10);

	}

	@Test
	@Order(7)
	void testInvalidGetServiceCharges() {

		Assertions.assertThrows(TokenNotFoundException.class,
				() -> this.ruleService.getServiceCharges(account1.getAccountId(), null));

	}

}
