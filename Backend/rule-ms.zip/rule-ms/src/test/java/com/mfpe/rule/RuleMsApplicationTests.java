package com.mfpe.rule;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuleMsApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
