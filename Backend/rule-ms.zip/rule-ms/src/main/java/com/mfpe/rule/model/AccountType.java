package com.mfpe.rule.model;

public enum AccountType {

	/**
	 *  AccountType enum for account categories
	 */
	SAVINGS,
	CURRENT
	
}
