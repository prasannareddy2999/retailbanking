package com.mfpe.rule.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mfpe.rule.dto.RuleStatus;
import com.mfpe.rule.dto.ServiceCharge;
import com.mfpe.rule.exception.TokenNotFoundException;
import com.mfpe.rule.feign.AccountFeign;
import com.mfpe.rule.model.AccountDto;

@Service
public class RuleServiceImpl implements RuleService {

	/**
	 * Service Layer class for Rule Microservice
	 */
	@Autowired
	private AccountFeign accountClient;

	@Override
	public RuleStatus evaluateMinBal(double amount, String accountId, String token) {
		
		if(token == null) {
			throw new TokenNotFoundException();
		}
		
		int min = 1000;

		ResponseEntity<AccountDto> account = accountClient.getAccount(token, accountId);
		double balance = account.getBody().getBalance();

		double diff = balance - amount;
		if (diff >= min) {
			return new RuleStatus("Allowed", "Completely OK");
		} else if (diff >= 0) {
			return new RuleStatus("Allowed", "Partially OK");
		} else {
			return new RuleStatus("Denied", "Not OK");
		}

	}

	@Override
	public ServiceCharge getServiceCharges(String accountId, String token) {

		if(token == null) {
			throw new TokenNotFoundException();
		}
		
		ResponseEntity<AccountDto> account = accountClient.getAccount(token, accountId);
		double balance = account.getBody().getBalance();
		ServiceCharge charges = new ServiceCharge();

		if (balance < 1000) {
			double amount = balance / 10;
			charges.setAccountId(accountId);
			charges.setMessage("balance is less than 1000, 10% from your account is detected");
			charges.setBalance(balance - amount);
		} else {
			charges.setAccountId(accountId);
			charges.setMessage("maintaining minimum amount, no detection");
			charges.setBalance(balance);
		}

		return charges;
	}

}
