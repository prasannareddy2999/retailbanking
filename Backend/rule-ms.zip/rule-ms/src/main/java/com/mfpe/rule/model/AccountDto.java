package com.mfpe.rule.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class AccountDto {

	/**
	 * AccountDto class for transferring the information
	 */
	@SuppressWarnings("unused")
	private String accountId;
	
	@Getter
	private double balance;

}
