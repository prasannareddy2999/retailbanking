package com.mfpe.rule.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class Account {

	/**
	 * Account Entity Class persisted in Repository
	 */
	@Getter
	private String accountId;

	@SuppressWarnings("unused")
	private String customerId;

	@Getter
	private double balance;

	@SuppressWarnings("unused")
	private AccountType accountType;

}