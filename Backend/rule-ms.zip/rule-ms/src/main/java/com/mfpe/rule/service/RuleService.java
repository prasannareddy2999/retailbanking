package com.mfpe.rule.service;

import com.mfpe.rule.dto.RuleStatus;
import com.mfpe.rule.dto.ServiceCharge;

public interface RuleService {

	/**
	 * Service Layer interface for Rule Microservice
	 */
	public RuleStatus evaluateMinBal(double amount, String accountId, String token);

	public ServiceCharge getServiceCharges(String accountId, String token);

}
