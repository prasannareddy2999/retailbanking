import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  public loggedIn=false;

  public customer=false;

  public employee=false;

  user:any = localStorage.getItem('userid');

  constructor(private loginService:LoginService) { }

  ngOnInit(): void {
    this.loggedIn = this.loginService.isLoggedIn();
    if(this.user.includes('EM')){
      this.employee = true;
    }
    else if(this.user.includes('CU')){
      this.customer = true;
    }
  }

  logoutUser(){
    this.loginService.logout();
    location.reload();
  }

  

}
