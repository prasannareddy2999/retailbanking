import { CustomerService } from './../services/customer.service';
import { Component, ElementRef, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  accountId: String = '';
  amount: number = 0;
  toAccountId: String = '';

  error: boolean = false;
  success: boolean = false;
  successMessage: String = '';
  errorMessage = "";


  constructor(private customerService: CustomerService, private elementRef: ElementRef) { }

  ngOnInit(): void {
  }

  withdraw_: boolean = false;
  deposit_: boolean = false;
  transfer_: boolean = false;
  getAccount_: boolean = false;
  getCustomer_: boolean = false;
  accountStatement_: boolean = false;

  withdraw() {
    this.error = false;
    this.success = false;
    this.withdraw_ = !this.withdraw_;
    this.accountStatement_ = false;
    this.deposit_ = false;
    this.getAccount_ = false;
    this.getCustomer_ = false;
    this.transfer_ = false;
  }

  deposit() {
    this.error = false;
    this.success = false;
    this.withdraw_ = false;
    this.accountStatement_ = false;
    this.deposit_ = !this.deposit_;
    this.getAccount_ = false;
    this.getCustomer_ = false;
    this.transfer_ = false;
  }

  transfer() {
    this.error = false;
    this.success = false;
    this.withdraw_ = false;
    this.accountStatement_ = false;
    this.deposit_ = false;
    this.getAccount_ = false;
    this.getCustomer_ = false;
    this.transfer_ = !this.transfer_;
  }

  getAccount() {
    this.error = false;
    this.success = false;
    this.withdraw_ = false;
    this.accountStatement_ = false;
    this.deposit_ = false;
    this.getAccount_ = !this.getAccount_;
    this.getCustomer_ = false;
    this.transfer_ = false;
  }

  getCustomer() {
    this.error = false;
    this.success = false;
    this.withdraw_ = false;
    this.accountStatement_ = false;
    this.deposit_ = false;
    this.getAccount_ = false;
    this.getCustomer_ = !this.getCustomer_;
    this.transfer_ = false;
  }

  accountStatement() {
    this.error = false;
    this.success = false;
    this.withdraw_ = false;
    this.accountStatement_ = !this.accountStatement_;
    this.deposit_ = false;
    this.getAccount_ = false;
    this.getCustomer_ = false;
    this.transfer_ = false;
  }

  onSubmitGetAccount() {
    if (this.accountId == null || this.accountId == "") {
      this.error = true;
      this.success = false;
      this.errorMessage = "Field is Empty";
    } else if ((this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) && !isNaN(Number(this.accountId.substring(5))) && this.accountId.length == 11) {
      this.error = false;
      console.log(this.accountId);
      this.customerService.getAccount(this.accountId).subscribe(
        (response: any) => {
          console.log(response);
          this.success = true;
          this.successMessage = `Your account ID: ${response.accountId}` + "<br><br>" + `Your current balance: ${response.balance}`;
        }, err => {
          this.error = true;
          this.success = false;
          this.errorMessage = err.error.message;
          console.log("error");
        }
      );
    }
    else {
      this.success = false;
      this.error = true;
      this.errorMessage = "Account Id must starts with SBACS or SBACC and contains six digits next to it";
    }
  }

  onSubmitDeposit() {
    if (this.accountId == null || this.accountId == "" || this.amount == null) {
      this.error = true;
      this.success = false;
      this.errorMessage = "Field is Empty";
    } else if ((this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) && !isNaN(Number(this.accountId.substring(5))) && this.accountId.length == 11 && this.amount > 0) {
      this.error = false;
      console.log(this.accountId);
      this.customerService.deposit(this.accountId, this.amount).subscribe(
        (response: any) => {
          console.log(response);
          this.success = true;
          this.successMessage = `${response.message}` + "<br><br>" + `Your source balance: ${response.sourceBalance}` + "<br><br>" + `Your destination balance: ${response.destinationBalance}`;
        }, err => {
          this.error = true;
          this.success = false;
          this.errorMessage = err.error.message;
        }
      );
    }
    else {
      this.success = false;
      this.error = true;

      if(!(this.amount > 0)) {
        this.errorMessage = "Amount must be greater than 0";
      }
      if(!(this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) || isNaN(Number(this.accountId.substring(5))) || !(this.accountId.length == 11)) {
        this.errorMessage = this.errorMessage + "<br><br>Account Id must starts with SBACS or SBACC and contains six digits next to it";
      }
      

    }
  }

  onSubmitWithdraw() {
    if (this.accountId == null || this.accountId == "" || this.amount == null) {
      this.error = true;
      this.success = false;
      this.errorMessage = "Field is Empty";
    } else if ((this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) && !isNaN(Number(this.accountId.substring(5))) && this.accountId.length == 11 && this.amount > 0) {
      this.error = false;
      console.log(this.accountId);
      this.customerService.withdraw(this.accountId, this.amount).subscribe(
        (response: any) => {
          console.log(response);
          this.success = true;
          this.successMessage = `${response.message}` + "<br><br>" + `Your source balance: ${response.sourceBalance}` + "<br><br>" + `Your destination balance: ${response.destinationBalance}`;
        }, err => {
          this.error = true;
          this.success = false;
         this.errorMessage = err.error.message;
          
        }
      );
    }
    else {
      this.success = false;
      this.error = true;

      if(!(this.amount > 0)) {
        this.errorMessage = "Amount must be greater than 0";
      }
      if(!(this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) || isNaN(Number(this.accountId.substring(5))) || !(this.accountId.length == 11)) {
        this.errorMessage = this.errorMessage + "<br><br>Account Id must starts with SBACS or SBACC and contains six digits next to it";
      }
      
    }
  }

  onSubmitTransfer() {
    if (this.accountId == null || this.accountId == "" || this.amount == null || this.toAccountId == null || this.toAccountId == "") {
      this.error = true;
      this.success = false;
      this.errorMessage = "Field is Empty";
    } else if (((this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) && !isNaN(Number(this.accountId.substring(5))) && this.accountId.length == 11) && ((this.toAccountId.startsWith("SBACS") || this.toAccountId.startsWith("SBACC")) && !isNaN(Number(this.toAccountId.substring(5))) && this.toAccountId.length == 11) && this.amount > 0) {
      this.error = false;
      console.log(this.accountId);
      this.customerService.transfer(this.accountId, this.toAccountId, this.amount).subscribe(
        (response: any) => {
          console.log(response);
          this.success = true;
          this.successMessage = `${response.message}` + "<br><br>" + `Your source balance: ${response.sourceBalance}` + "<br><br>" + `Your destination balance: ${response.destinationBalance}`;
        }, err => {
          this.error = true;
          this.success = false;
         this.errorMessage = err.error.message;
          
        }
      );
    }
    else {
      this.success = false;
      this.error = true;

      if(!(this.amount > 0)) {
        this.errorMessage = "Amount must be greater than 0";
      }
      if(!(this.accountId.startsWith("SBACS") || this.accountId.startsWith("SBACC")) || isNaN(Number(this.accountId.substring(5))) || !(this.accountId.length == 11)) {
        this.errorMessage = this.errorMessage + "<br><br>From Account Id must starts with SBACS or SBACC and contains six digits next to it";
      }
      if(!(this.toAccountId.startsWith("SBACS") || this.toAccountId.startsWith("SBACC")) || isNaN(Number(this.toAccountId.substring(5))) || !(this.toAccountId.length == 11)) {
        this.errorMessage = this.errorMessage + "<br><br>To Account Id must starts with SBACS or SBACC and contains six digits next to it";
      }
      
    }
  }

}
